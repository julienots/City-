# Règles Proguard - Pocket Map
-keep class org.osmdroid.** { *; }
