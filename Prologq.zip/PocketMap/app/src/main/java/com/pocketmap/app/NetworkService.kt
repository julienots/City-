package com.pocketmap.app

import android.os.Handler
import android.os.Looper
import com.google.gson.JsonArray
import com.google.gson.JsonParser
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.URLEncoder

data class SearchResult(val displayName: String, val lat: Double, val lon: Double)
data class RouteResult(val distanceMeters: Double, val durationSeconds: Double, val points: List<Pair<Double, Double>>)

/**
 * Toutes les requêtes réseau de l'application, basées uniquement sur des
 * services publics et gratuits d'OpenStreetMap (aucune clé API payante).
 */
object NetworkService {

    private val client = OkHttpClient()
    private val mainHandler = Handler(Looper.getMainLooper())
    private const val USER_AGENT = "PocketMap-Android/1.0 (contact: pocketmap.app)"

    fun searchPlace(query: String, onResult: (List<SearchResult>) -> Unit, onError: (String) -> Unit) {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = "https://nominatim.openstreetmap.org/search?q=$encoded&format=json&limit=6&addressdetails=0"
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                mainHandler.post { onError(e.message ?: "network_error") }
            }

            override fun onResponse(call: Call, response: okhttp3.Response) {
                response.use {
                    if (!it.isSuccessful) {
                        mainHandler.post { onError("http_${it.code}") }
                        return
                    }
                    try {
                        val body = it.body?.string().orEmpty()
                        val jsonArray = JsonParser.parseString(body).asJsonArray
                        val results = parseSearchResults(jsonArray)
                        mainHandler.post { onResult(results) }
                    } catch (e: Exception) {
                        mainHandler.post { onError(e.message ?: "parse_error") }
                    }
                }
            }
        })
    }

    private fun parseSearchResults(jsonArray: JsonArray): List<SearchResult> {
        val results = mutableListOf<SearchResult>()
        for (element in jsonArray) {
            val obj = element.asJsonObject
            val name = obj.get("display_name")?.asString ?: continue
            val lat = obj.get("lat")?.asString?.toDoubleOrNull() ?: continue
            val lon = obj.get("lon")?.asString?.toDoubleOrNull() ?: continue
            results.add(SearchResult(name, lat, lon))
        }
        return results
    }

    fun getRoute(
        startLat: Double, startLon: Double,
        endLat: Double, endLon: Double,
        onResult: (RouteResult) -> Unit,
        onError: (String) -> Unit
    ) {
        val url = "https://router.project-osrm.org/route/v1/driving/" +
                "$startLon,$startLat;$endLon,$endLat?overview=full&geometries=geojson"
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                mainHandler.post { onError(e.message ?: "network_error") }
            }

            override fun onResponse(call: Call, response: okhttp3.Response) {
                response.use {
                    if (!it.isSuccessful) {
                        mainHandler.post { onError("http_${it.code}") }
                        return
                    }
                    try {
                        val body = it.body?.string().orEmpty()
                        val json = JsonParser.parseString(body).asJsonObject
                        val code = json.get("code")?.asString
                        if (code != "Ok") {
                            mainHandler.post { onError(code ?: "route_error") }
                            return
                        }
                        val route = json.getAsJsonArray("routes")[0].asJsonObject
                        val distance = route.get("distance").asDouble
                        val duration = route.get("duration").asDouble
                        val coordsArray = route.getAsJsonObject("geometry").getAsJsonArray("coordinates")
                        val points = mutableListOf<Pair<Double, Double>>()
                        for (c in coordsArray) {
                            val pair = c.asJsonArray
                            val lon = pair[0].asDouble
                            val lat = pair[1].asDouble
                            points.add(lat to lon)
                        }
                        mainHandler.post { onResult(RouteResult(distance, duration, points)) }
                    } catch (e: Exception) {
                        mainHandler.post { onError(e.message ?: "parse_error") }
                    }
                }
            }
        })
    }
}
