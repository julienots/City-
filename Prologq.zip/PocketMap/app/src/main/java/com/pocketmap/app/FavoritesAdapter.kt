package com.pocketmap.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

class FavoritesAdapter(
    private val onItemClick: (Favorite) -> Unit,
    private val onDeleteClick: (Favorite) -> Unit
) : RecyclerView.Adapter<FavoritesAdapter.FavoriteViewHolder>() {

    private val items = mutableListOf<Favorite>()

    fun submitList(newItems: List<Favorite>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_favorite, parent, false)
        return FavoriteViewHolder(view)
    }

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        val favorite = items[position]
        holder.name.text = favorite.name
        holder.coords.text = String.format(Locale.getDefault(), "%.4f, %.4f", favorite.lat, favorite.lon)
        holder.itemView.setOnClickListener { onItemClick(favorite) }
        holder.deleteButton.setOnClickListener { onDeleteClick(favorite) }
    }

    override fun getItemCount(): Int = items.size

    class FavoriteViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.favoriteName)
        val coords: TextView = view.findViewById(R.id.favoriteCoords)
        val deleteButton: ImageButton = view.findViewById(R.id.btnDeleteFavorite)
    }
}
