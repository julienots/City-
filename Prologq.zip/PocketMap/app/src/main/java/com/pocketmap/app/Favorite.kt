package com.pocketmap.app

/**
 * Représente un lieu favori sauvegardé par l'utilisateur.
 */
data class Favorite(
    val id: Long = System.currentTimeMillis(),
    val name: String,
    val lat: Double,
    val lon: Double
)
