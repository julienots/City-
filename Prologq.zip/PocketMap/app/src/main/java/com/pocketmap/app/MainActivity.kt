package com.pocketmap.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.animation.AnimationUtils
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var map: MapView
    private lateinit var myLocationOverlay: MyLocationNewOverlay
    private lateinit var favoritesManager: FavoritesManager
    private lateinit var favoritesAdapter: FavoritesAdapter
    private lateinit var bottomSheetBehavior: BottomSheetBehavior<LinearLayout>

    private var selectedMarker: Marker? = null
    private var selectedPlaceName: String = ""
    private var selectedPoint: GeoPoint? = null
    private var routeLine: Polyline? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            enableLocation()
        } else {
            toast(getString(R.string.permission_denied))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // osmdroid a besoin d'une configuration (user-agent + cache) avant tout usage.
        Configuration.getInstance().load(
            applicationContext,
            getSharedPreferences("osmdroid_prefs", MODE_PRIVATE)
        )
        Configuration.getInstance().userAgentValue = packageName
        Configuration.getInstance().osmdroidTileCache = java.io.File(cacheDir, "osmdroid/tiles")
        Configuration.getInstance().osmdroidBasePath = java.io.File(cacheDir, "osmdroid")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        favoritesManager = FavoritesManager(this)

        setupMap()
        setupSearchBar()
        setupFabs()
        setupFavoritesSheet()
        checkLocationPermission()
    }

    // ---------- Carte ----------

    private fun setupMap() {
        map = findViewById(R.id.map)
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.setBuiltInZoomControls(false)
        map.controller.setZoom(15.0)
        map.controller.setCenter(GeoPoint(48.8566, 2.3522)) // Paris par défaut tant que le GPS n'a pas répondu

        myLocationOverlay = MyLocationNewOverlay(GpsMyLocationProvider(this), map)
        map.overlays.add(myLocationOverlay)

        // Appui simple / long sur la carte -> sélectionne un point (dépose un repère)
        val receiver = object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                collapseFavoritesSheet()
                placeSelection(p, getString(R.string.add_favorite))
                return true
            }

            override fun longPressHelper(p: GeoPoint): Boolean {
                collapseFavoritesSheet()
                placeSelection(p, "Lieu sélectionné")
                return true
            }
        }
        map.overlays.add(0, MapEventsOverlay(receiver))
    }

    private fun checkLocationPermission() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED) {
            enableLocation()
        } else {
            toast(getString(R.string.permission_needed))
            permissionLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        }
    }

    private fun enableLocation() {
        myLocationOverlay.enableMyLocation()
        myLocationOverlay.runOnFirstFix {
            runOnUiThread {
                myLocationOverlay.myLocation?.let { loc ->
                    map.controller.animateTo(loc)
                }
            }
        }
    }

    // ---------- Barre de recherche ----------

    private fun setupSearchBar() {
        val searchInput = findViewById<EditText>(R.id.searchInput)
        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performSearch(searchInput.text.toString())
                true
            } else {
                false
            }
        }
    }

    private fun performSearch(query: String) {
        if (query.isBlank()) return
        collapseFavoritesSheet()
        NetworkService.searchPlace(
            query = query,
            onResult = { results ->
                if (results.isEmpty()) {
                    toast(getString(R.string.search_no_result))
                } else {
                    val best = results.first()
                    val point = GeoPoint(best.lat, best.lon)
                    map.controller.animateTo(point)
                    map.controller.setZoom(16.0)
                    placeSelection(point, best.displayName.substringBefore(","))
                }
            },
            onError = {
                Log.w("PocketMap", "Erreur recherche: $it")
                toast(getString(R.string.search_error))
            }
        )
    }

    // ---------- Sélection d'un lieu (recherche, favori ou tap sur la carte) ----------

    private fun placeSelection(point: GeoPoint, name: String) {
        selectedPoint = point
        selectedPlaceName = name

        selectedMarker?.let { map.overlays.remove(it) }
        val marker = Marker(map).apply {
            position = point
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            icon = ContextCompat.getDrawable(this@MainActivity, R.drawable.ic_marker)
            title = name
        }
        map.overlays.add(marker)
        selectedMarker = marker
        map.invalidate()

        val myLoc = myLocationOverlay.myLocation
        if (myLoc != null) {
            computeRoute(myLoc, point)
        }
    }

    // ---------- Itinéraire ----------

    private fun computeRoute(from: GeoPoint, to: GeoPoint) {
        NetworkService.getRoute(
            startLat = from.latitude, startLon = from.longitude,
            endLat = to.latitude, endLon = to.longitude,
            onResult = { route ->
                drawRoute(route)
            },
            onError = {
                Log.w("PocketMap", "Erreur itinéraire: $it")
                // Pas de route routable (ex: point en mer) -> on garde juste le repère.
            }
        )
    }

    private fun drawRoute(route: RouteResult) {
        routeLine?.let { map.overlays.remove(it) }
        val points = route.points.map { GeoPoint(it.first, it.second) }
        val polyline = Polyline(map).apply {
            setPoints(points)
            outlinePaint.color = ContextCompat.getColor(this@MainActivity, R.color.route_color)
            outlinePaint.strokeWidth = 10f
        }
        map.overlays.add(polyline)
        routeLine = polyline
        map.invalidate()

        val card = findViewById<LinearLayout>(R.id.routeInfoCard)
        val text = findViewById<TextView>(R.id.routeInfoText)
        text.text = formatRouteInfo(route.distanceMeters, route.durationSeconds)
        card.visibility = LinearLayout.VISIBLE
        card.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in))
    }

    private fun formatRouteInfo(distanceMeters: Double, durationSeconds: Double): String {
        val km = distanceMeters / 1000.0
        val distanceText = if (km < 1) "${distanceMeters.roundToInt()} m" else String.format(Locale.getDefault(), "%.1f km", km)
        val minutes = (durationSeconds / 60.0).roundToInt()
        val durationText = if (minutes < 1) "< 1 min" else "$minutes min"
        return "$distanceText · $durationText"
    }

    private fun clearRoute() {
        routeLine?.let { map.overlays.remove(it) }
        routeLine = null
        findViewById<LinearLayout>(R.id.routeInfoCard).visibility = LinearLayout.GONE
        map.invalidate()
    }

    // ---------- Boutons flottants ----------

    private fun setupFabs() {
        findViewById<FloatingActionButton>(R.id.btnMyLocation).setOnClickListener {
            val loc = myLocationOverlay.myLocation
            if (loc != null) {
                map.controller.animateTo(loc)
                map.controller.setZoom(17.0)
            } else {
                toast(getString(R.string.location_unavailable))
                checkLocationPermission()
            }
        }

        findViewById<FloatingActionButton>(R.id.btnAddFavorite).setOnClickListener {
            showAddFavoriteDialog()
        }

        findViewById<FloatingActionButton>(R.id.btnShare).setOnClickListener {
            shareCurrentPlace()
        }

        findViewById<ImageButton>(R.id.btnClearRoute).setOnClickListener {
            clearRoute()
        }
    }

    private fun showAddFavoriteDialog() {
        val point = selectedPoint ?: myLocationOverlay.myLocation
        if (point == null) {
            toast("Sélectionnez d'abord un lieu sur la carte ou via la recherche.")
            return
        }
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_favorite, null)
        val subtitle = dialogView.findViewById<TextView>(R.id.dialogSubtitle)
        val nameInput = dialogView.findViewById<EditText>(R.id.favoriteNameInput)
        subtitle.text = String.format(Locale.getDefault(), "%.5f, %.5f", point.latitude, point.longitude)
        nameInput.setText(if (selectedPlaceName.isNotBlank()) selectedPlaceName else "Nouveau favori")

        AlertDialog.Builder(this)
            .setTitle(R.string.add_favorite)
            .setView(dialogView)
            .setPositiveButton(R.string.add) { _, _ ->
                val name = nameInput.text.toString().ifBlank { "Favori" }
                favoritesManager.addFavorite(Favorite(name = name, lat = point.latitude, lon = point.longitude))
                refreshFavoritesList()
                toast("Ajouté aux favoris")
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun shareCurrentPlace() {
        val point = selectedPoint ?: myLocationOverlay.myLocation
        if (point == null) {
            toast(getString(R.string.location_unavailable))
            return
        }
        val name = if (selectedPoint != null && selectedPlaceName.isNotBlank()) selectedPlaceName else "Ma position"
        val mapUrl = "https://www.openstreetmap.org/?mlat=${point.latitude}&mlon=${point.longitude}#map=17/${point.latitude}/${point.longitude}"
        val text = "$name\n$mapUrl"

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            putExtra(Intent.EXTRA_SUBJECT, name)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share)))
    }

    // ---------- Panneau des favoris ----------

    private fun setupFavoritesSheet() {
        val sheet = findViewById<LinearLayout>(R.id.favoritesSheet)
        bottomSheetBehavior = BottomSheetBehavior.from(sheet)
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_HIDDEN

        val recyclerView = findViewById<RecyclerView>(R.id.favoritesRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        favoritesAdapter = FavoritesAdapter(
            onItemClick = { favorite ->
                val point = GeoPoint(favorite.lat, favorite.lon)
                map.controller.animateTo(point)
                map.controller.setZoom(17.0)
                placeSelection(point, favorite.name)
                collapseFavoritesSheet()
            },
            onDeleteClick = { favorite ->
                favoritesManager.removeFavorite(favorite.id)
                refreshFavoritesList()
            }
        )
        recyclerView.adapter = favoritesAdapter

        findViewById<ImageButton>(R.id.btnFavoritesList).setOnClickListener {
            refreshFavoritesList()
            if (bottomSheetBehavior.state == BottomSheetBehavior.STATE_HIDDEN ||
                bottomSheetBehavior.state == BottomSheetBehavior.STATE_COLLAPSED
            ) {
                bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
            } else {
                bottomSheetBehavior.state = BottomSheetBehavior.STATE_HIDDEN
            }
        }

        refreshFavoritesList()
    }

    private fun refreshFavoritesList() {
        val favorites = favoritesManager.getFavorites()
        favoritesAdapter.submitList(favorites)
        findViewById<TextView>(R.id.emptyFavoritesText).visibility =
            if (favorites.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun collapseFavoritesSheet() {
        if (::bottomSheetBehavior.isInitialized) {
            bottomSheetBehavior.state = BottomSheetBehavior.STATE_HIDDEN
        }
    }

    // ---------- Cycle de vie osmdroid ----------

    override fun onResume() {
        super.onResume()
        map.onResume()
    }

    override fun onPause() {
        super.onPause()
        map.onPause()
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
