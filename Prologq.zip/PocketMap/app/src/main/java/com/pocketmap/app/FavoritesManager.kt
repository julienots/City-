package com.pocketmap.app

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * Sauvegarde et charge la liste des favoris localement sur l'appareil,
 * via SharedPreferences (aucun serveur, aucun compte requis).
 */
class FavoritesManager(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    fun getFavorites(): MutableList<Favorite> {
        val json = prefs.getString(KEY_FAVORITES, null) ?: return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<Favorite>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun addFavorite(favorite: Favorite) {
        val list = getFavorites()
        list.add(0, favorite)
        save(list)
    }

    fun removeFavorite(id: Long) {
        val list = getFavorites()
        list.removeAll { it.id == id }
        save(list)
    }

    fun isFavorite(lat: Double, lon: Double, thresholdMeters: Double = 15.0): Boolean {
        return getFavorites().any { distanceMeters(it.lat, it.lon, lat, lon) < thresholdMeters }
    }

    private fun save(list: List<Favorite>) {
        prefs.edit().putString(KEY_FAVORITES, gson.toJson(list)).apply()
    }

    private fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val results = FloatArray(1)
        android.location.Location.distanceBetween(lat1, lon1, lat2, lon2, results)
        return results[0].toDouble()
    }

    companion object {
        private const val PREFS_NAME = "pocket_map_prefs"
        private const val KEY_FAVORITES = "favorites_json"
    }
}
